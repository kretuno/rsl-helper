import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';

void main() {
  runApp(const ShardMercyApp());
}

const _background = Color(0xFF1C1C1C);
const _panel = Color(0xFF242424);
const _card = Color(0xFF292929);
const _field = Color(0xFF343434);
const _muted = Color(0xFF8E8E8E);
const _gold = Color(0xFFFFAA00);
const _blue = Color(0xFF148DFF);
const _purple = Color(0xFFFF22F8);
const _red = Color(0xFFFF1515);
const _yellow = Color(0xFFFFE500);

class ShardMercyApp extends StatelessWidget {
  const ShardMercyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'RSL Shard Memory',
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        scaffoldBackgroundColor: _background,
        colorScheme: ColorScheme.fromSeed(
          seedColor: _gold,
          brightness: Brightness.dark,
          surface: _panel,
        ),
        fontFamily: 'Arial',
      ),
      home: const ShardOverviewScreen(),
    );
  }
}

class ShardCounter {
  const ShardCounter({
    required this.id,
    required this.title,
    required this.description,
    required this.assetPath,
    required this.accentColor,
    required this.current,
    required this.threshold,
    required this.chanceLabel,
    required this.rewardType,
  });

  final String id;
  final String title;
  final String description;
  final String assetPath;
  final Color accentColor;
  final int current;
  final int threshold;
  final String chanceLabel;
  final String rewardType;

  double get progress =>
      threshold == 0 ? 0 : (current / threshold).clamp(0.0, 1.0).toDouble();

  ShardCounter copyWith({int? current}) {
    return ShardCounter(
      id: id,
      title: title,
      description: description,
      assetPath: assetPath,
      accentColor: accentColor,
      current: current ?? this.current,
      threshold: threshold,
      chanceLabel: chanceLabel,
      rewardType: rewardType,
    );
  }

  Map<String, Object?> toJson() => {'id': id, 'current': current};
}

class HistoryEntry {
  const HistoryEntry({
    required this.id,
    required this.counterId,
    required this.action,
    required this.delta,
    required this.before,
    required this.after,
    required this.createdAt,
  });

  final String id;
  final String counterId;
  final String action;
  final int delta;
  final int before;
  final int after;
  final DateTime createdAt;

  Map<String, Object?> toJson() => {
    'id': id,
    'counterId': counterId,
    'action': action,
    'delta': delta,
    'before': before,
    'after': after,
    'createdAt': createdAt.toIso8601String(),
  };

  static HistoryEntry fromJson(Map<String, Object?> json) {
    return HistoryEntry(
      id: json['id'] as String? ?? '',
      counterId: json['counterId'] as String? ?? '',
      action: json['action'] as String? ?? '',
      delta: (json['delta'] as num?)?.toInt() ?? 0,
      before: (json['before'] as num?)?.toInt() ?? 0,
      after: (json['after'] as num?)?.toInt() ?? 0,
      createdAt:
          DateTime.tryParse(json['createdAt'] as String? ?? '') ??
          DateTime.fromMillisecondsSinceEpoch(0),
    );
  }
}

class AppStateSnapshot {
  const AppStateSnapshot({required this.currents, required this.history});

  final Map<String, int> currents;
  final List<HistoryEntry> history;
}

class ShardStore {
  Future<AppStateSnapshot?> load() async {
    final file = await _stateFile();
    if (!await file.exists()) {
      return null;
    }

    final raw = await file.readAsString();
    return decode(raw);
  }

  static AppStateSnapshot decode(String raw) {
    final json = jsonDecode(raw) as Map<String, Object?>;
    final counters = <String, int>{};
    final rawCounters = json['counters'];
    if (rawCounters is List) {
      for (final entry in rawCounters) {
        if (entry is Map) {
          final id = entry['id'] as String?;
          final current = (entry['current'] as num?)?.toInt();
          if (id != null && current != null) {
            counters[id] = current;
          }
        }
      }
    }

    final history = <HistoryEntry>[];
    final rawHistory = json['history'];
    if (rawHistory is List) {
      for (final entry in rawHistory) {
        if (entry is Map) {
          history.add(HistoryEntry.fromJson(Map<String, Object?>.from(entry)));
        }
      }
    }

    return AppStateSnapshot(currents: counters, history: history);
  }

  static String encode(
    List<ShardCounter> counters,
    List<HistoryEntry> history,
  ) {
    return const JsonEncoder.withIndent('  ').convert({
      'version': 1,
      'savedAt': DateTime.now().toIso8601String(),
      'counters': counters.map((counter) => counter.toJson()).toList(),
      'history': history.map((entry) => entry.toJson()).toList(),
    });
  }

  Future<void> save(
    List<ShardCounter> counters,
    List<HistoryEntry> history,
  ) async {
    final file = await _stateFile();
    await file.parent.create(recursive: true);
    await file.writeAsString(encode(counters, history));
  }

  Future<File> _stateFile() async {
    return File('${await _basePath()}${Platform.pathSeparator}state.json');
  }

  Future<String> _basePath() async {
    final env = Platform.environment;
    if (Platform.isWindows) {
      return '${env['APPDATA'] ?? Directory.current.path}${Platform.pathSeparator}RaidShardCounter';
    }
    if (Platform.isMacOS) {
      return '${env['HOME'] ?? Directory.current.path}${Platform.pathSeparator}Library${Platform.pathSeparator}Application Support${Platform.pathSeparator}RaidShardCounter';
    }
    if (Platform.isAndroid) {
      const channel = MethodChannel('raid_shard_counter/app_paths');
      final path = await channel.invokeMethod<String>('dataDir');
      if (path != null && path.isNotEmpty) {
        return '$path${Platform.pathSeparator}RaidShardCounter';
      }
      return '${Directory.systemTemp.path}${Platform.pathSeparator}RaidShardCounter';
    }
    return '${env['XDG_DATA_HOME'] ?? '${env['HOME'] ?? Directory.current.path}${Platform.pathSeparator}.local${Platform.pathSeparator}share'}${Platform.pathSeparator}RaidShardCounter';
  }
}

List<ShardCounter> defaultCounters() {
  return const [
    ShardCounter(
      id: 'ancient',
      title: 'Древний осколок',
      description: 'Призывает редкого, эпического или легендарного героя.',
      assetPath: 'assets/shards/ancient.png',
      accentColor: _blue,
      current: 53,
      threshold: 219,
      chanceLabel: 'Legendary chance: 0,5%',
      rewardType: 'legendary',
    ),
    ShardCounter(
      id: 'void',
      title: 'Темный осколок',
      description: 'Призывает редкого, эпического или легендарного героя Тьмы.',
      assetPath: 'assets/shards/void.png',
      accentColor: _purple,
      current: 12,
      threshold: 219,
      chanceLabel: 'Legendary chance: 0,5%',
      rewardType: 'legendary',
    ),
    ShardCounter(
      id: 'sacred',
      title: 'Сакральный осколок',
      description: 'Призывает эпического или легендарного героя.',
      assetPath: 'assets/shards/sacred.png',
      accentColor: _yellow,
      current: 2,
      threshold: 22,
      chanceLabel: 'Legendary chance: 6%',
      rewardType: 'legendary',
    ),
    ShardCounter(
      id: 'primal_mythical',
      title: 'Первозданный осколок',
      description: 'Отслеживание шанса мифического героя.',
      assetPath: 'assets/shards/primal.png',
      accentColor: _red,
      current: 1,
      threshold: 209,
      chanceLabel: 'Mythical chance: 0,5%',
      rewardType: 'mythical',
    ),
    ShardCounter(
      id: 'primal_legendary',
      title: 'Первозданный осколок',
      description: 'Отслеживание шанса легендарного героя.',
      assetPath: 'assets/shards/primal_alt.png',
      accentColor: _gold,
      current: 1,
      threshold: 51,
      chanceLabel: 'Legendary chance: 6%',
      rewardType: 'legendary',
    ),
    ShardCounter(
      id: 'zircon',
      title: 'Циркон',
      description: 'Счетчик проклятого циркона для мифического героя.',
      assetPath: 'assets/shards/zircon.png',
      accentColor: _red,
      current: 0,
      threshold: 121,
      chanceLabel: 'Mythical chance: 2,5%',
      rewardType: 'mythical',
    ),
  ];
}

class ShardOverviewScreen extends StatefulWidget {
  const ShardOverviewScreen({super.key});

  @override
  State<ShardOverviewScreen> createState() => _ShardOverviewScreenState();
}

class _ShardOverviewScreenState extends State<ShardOverviewScreen> {
  final _store = ShardStore();
  late List<ShardCounter> _counters = defaultCounters();
  List<HistoryEntry> _history = const [];
  bool _isLoading = true;
  bool _showHistory = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final snapshot = await _store.load();
    if (!mounted) {
      return;
    }
    setState(() {
      if (snapshot != null) {
        _counters = _counters
            .map(
              (counter) =>
                  counter.copyWith(current: snapshot.currents[counter.id]),
            )
            .toList();
        _history = snapshot.history;
      }
      _isLoading = false;
    });
  }

  Future<void> _save() => _store.save(_counters, _history);

  void _changeCounter(ShardCounter counter, int value, String action) {
    final before = counter.current;
    final after = value.clamp(0, counter.threshold).toInt();
    if (before == after && action != 'reset') {
      return;
    }
    final nextHistory = HistoryEntry(
      id: '${DateTime.now().microsecondsSinceEpoch}_${counter.id}',
      counterId: counter.id,
      action: action,
      delta: after - before,
      before: before,
      after: after,
      createdAt: DateTime.now(),
    );
    setState(() {
      _counters = _counters
          .map(
            (item) =>
                item.id == counter.id ? item.copyWith(current: after) : item,
          )
          .toList();
      _history = [nextHistory, ..._history].take(300).toList();
    });
    _save();
  }

  void _showHistorySheet() {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: _panel,
      showDragHandle: true,
      isScrollControlled: true,
      builder: (context) => DraggableScrollableSheet(
        initialChildSize: 0.72,
        maxChildSize: 0.92,
        minChildSize: 0.35,
        expand: false,
        builder: (context, controller) => HistoryList(
          history: _history,
          counters: _counters,
          controller: controller,
        ),
      ),
    );
  }

  void _showAppInfo() {
    showDialog<void>(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: _panel,
        title: const Text('RSL Shard Memory 1.0.1'),
        content: const SingleChildScrollView(
          child: Text(
            'Приложение предназначено для ручного учета счетчиков открытия осколков.\n\n'
            'Разработчик: Eduard Osipov\n'
            'Email: edosipov@gmail.com\n\n'
            'Все спрайты, изображения, названия и связанные визуальные материалы RAID: Shadow Legends являются собственностью Plarium.\n\n'
            'Приложение не является официальным продуктом Plarium и несет исключительно ознакомительный и информационный характер.',
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Закрыть'),
          ),
        ],
      ),
    );
  }

  Future<void> _openDonationUrl() async {
    final url = Uri.parse('https://send.monobank.ua/jar/mHTsyv3bB');
    final opened = await launchUrl(url, mode: LaunchMode.externalApplication);
    if (!opened && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Не удалось открыть ссылку')),
      );
    }
  }

  Future<void> _exportData() async {
    final payload = ShardStore.encode(_counters, _history);
    final now = DateTime.now();
    String two(int value) => value.toString().padLeft(2, '0');
    final fileName =
        'rsl-shard-memory-${now.year}-${two(now.month)}-${two(now.day)}.json';
    final savedPath = await FilePicker.platform.saveFile(
      dialogTitle: 'Экспорт данных RSL Shard Memory',
      fileName: fileName,
      type: FileType.custom,
      allowedExtensions: const ['json'],
      bytes: Uint8List.fromList(utf8.encode(payload)),
      lockParentWindow: true,
    );
    if (!mounted) {
      return;
    }
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          savedPath == null
              ? 'Экспорт отменен'
              : 'Данные экспортированы: $savedPath',
        ),
      ),
    );
  }

  Future<void> _importData() async {
    final result = await FilePicker.platform.pickFiles(
      dialogTitle: 'Импорт данных RSL Shard Memory',
      type: FileType.custom,
      allowedExtensions: const ['json'],
      lockParentWindow: true,
    );
    final path = result?.files.single.path;
    if (path == null) {
      return;
    }

    try {
      final snapshot = ShardStore.decode(await File(path).readAsString());
      if (snapshot.currents.isEmpty) {
        throw const FormatException('Файл не содержит счетчики.');
      }
      if (!mounted) {
        return;
      }
      final confirmed = await showDialog<bool>(
        context: context,
        builder: (context) => AlertDialog(
          backgroundColor: _panel,
          title: const Text('Импортировать данные?'),
          content: Text(
            'Будут заменены текущие счетчики и история.\n\n'
            'Счетчиков в файле: ${snapshot.currents.length}\n'
            'Записей истории: ${snapshot.history.length}',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(false),
              child: const Text('Отмена'),
            ),
            FilledButton(
              onPressed: () => Navigator.of(context).pop(true),
              child: const Text('Импортировать'),
            ),
          ],
        ),
      );
      if (confirmed != true || !mounted) {
        return;
      }
      setState(() {
        _counters = defaultCounters()
            .map(
              (counter) =>
                  counter.copyWith(current: snapshot.currents[counter.id]),
            )
            .toList();
        _history = snapshot.history;
      });
      await _save();
      if (!mounted) {
        return;
      }
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text('Данные импортированы')));
    } catch (error) {
      if (!mounted) {
        return;
      }
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Не удалось импортировать файл: $error')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final isWide = MediaQuery.sizeOf(context).width >= 920;

    return Scaffold(
      body: SafeArea(
        child: _isLoading
            ? const Center(child: CircularProgressIndicator(color: _gold))
            : Column(
                children: [
                  _TopBar(
                    showHistory: _showHistory,
                    onHistoryPressed: isWide
                        ? () => setState(() => _showHistory = !_showHistory)
                        : _showHistorySheet,
                    onInfoPressed: _showAppInfo,
                    onDonatePressed: _openDonationUrl,
                    onImportPressed: _importData,
                    onExportPressed: _exportData,
                  ),
                  Expanded(
                    child: isWide
                        ? Row(
                            children: [
                              SizedBox(
                                width: 300,
                                child: CounterSidebar(counters: _counters),
                              ),
                              Expanded(
                                child: _CounterWorkspace(
                                  counters: _counters,
                                  onChange: _changeCounter,
                                ),
                              ),
                              if (_showHistory)
                                SizedBox(
                                  width: 360,
                                  child: HistoryList(
                                    history: _history,
                                    counters: _counters,
                                  ),
                                ),
                            ],
                          )
                        : _MobileWorkspace(
                            counters: _counters,
                            history: _history,
                            onChange: _changeCounter,
                          ),
                  ),
                ],
              ),
      ),
    );
  }
}

class _TopBar extends StatelessWidget {
  const _TopBar({
    required this.showHistory,
    required this.onHistoryPressed,
    required this.onInfoPressed,
    required this.onDonatePressed,
    required this.onImportPressed,
    required this.onExportPressed,
  });

  final bool showHistory;
  final VoidCallback onHistoryPressed;
  final VoidCallback onInfoPressed;
  final VoidCallback onDonatePressed;
  final VoidCallback onImportPressed;
  final VoidCallback onExportPressed;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 54,
      color: const Color(0xFF181818),
      padding: const EdgeInsets.symmetric(horizontal: 18),
      child: Row(
        children: [
          const Text(
            'RSL Shard Memory',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800),
          ),
          const SizedBox(width: 10),
          const Text(
            'v1.0.1',
            style: TextStyle(
              color: _muted,
              fontSize: 13,
              fontWeight: FontWeight.w800,
            ),
          ),
          const Spacer(),
          Tooltip(
            message: 'Импорт данных',
            child: IconButton(
              onPressed: onImportPressed,
              color: Colors.white,
              icon: const Icon(Icons.file_upload_outlined, size: 20),
            ),
          ),
          Tooltip(
            message: 'Экспорт данных',
            child: IconButton(
              onPressed: onExportPressed,
              color: Colors.white,
              icon: const Icon(Icons.file_download_outlined, size: 20),
            ),
          ),
          TextButton(
            onPressed: onDonatePressed,
            style: TextButton.styleFrom(
              foregroundColor: _gold,
              padding: const EdgeInsets.symmetric(horizontal: 12),
            ),
            child: const Text('Помочь проекту'),
          ),
          Tooltip(
            message: 'О приложении',
            child: IconButton(
              onPressed: onInfoPressed,
              color: Colors.white,
              icon: const Icon(Icons.info_outline, size: 20),
            ),
          ),
          Tooltip(
            message: 'История',
            child: IconButton(
              onPressed: onHistoryPressed,
              color: showHistory ? _gold : Colors.white,
              icon: const Icon(Icons.history, size: 20),
            ),
          ),
        ],
      ),
    );
  }
}

class CounterSidebar extends StatelessWidget {
  const CounterSidebar({required this.counters, super.key});

  final List<ShardCounter> counters;

  @override
  Widget build(BuildContext context) {
    return Container(
      color: const Color(0xFF222222),
      padding: const EdgeInsets.fromLTRB(16, 18, 16, 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Padding(
            padding: EdgeInsets.only(left: 6, bottom: 18),
            child: Text(
              'Shard Overview',
              style: TextStyle(fontSize: 25, fontWeight: FontWeight.w300),
            ),
          ),
          Expanded(
            child: ListView.separated(
              itemCount: counters.length,
              separatorBuilder: (_, __) => const SizedBox(height: 10),
              itemBuilder: (context, index) =>
                  _SidebarTile(counter: counters[index]),
            ),
          ),
        ],
      ),
    );
  }
}

class _SidebarTile extends StatelessWidget {
  const _SidebarTile({required this.counter});

  final ShardCounter counter;

  @override
  Widget build(BuildContext context) {
    return Container(
      constraints: const BoxConstraints(minHeight: 108),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: _card,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: counter.accentColor, width: 1.5),
      ),
      child: Row(
        children: [
          SizedBox(
            width: 78,
            child: Stack(
              alignment: Alignment.bottomCenter,
              children: [
                Image.asset(
                  counter.assetPath,
                  width: 72,
                  height: 72,
                  fit: BoxFit.contain,
                ),
                Text(
                  '${counter.current}',
                  style: const TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  counter.title,
                  style: const TextStyle(
                    color: _gold,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  counter.description,
                  style: const TextStyle(fontSize: 13, height: 1.2),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _CounterWorkspace extends StatelessWidget {
  const _CounterWorkspace({required this.counters, required this.onChange});

  final List<ShardCounter> counters;
  final void Function(ShardCounter counter, int value, String action) onChange;

  @override
  Widget build(BuildContext context) {
    return Container(
      color: _background,
      padding: const EdgeInsets.fromLTRB(24, 22, 24, 18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Компенсация неудач',
            style: TextStyle(fontSize: 26, fontWeight: FontWeight.w300),
          ),
          const SizedBox(height: 20),
          Expanded(
            child: GridView.builder(
              itemCount: counters.length,
              gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
                maxCrossAxisExtent: 415,
                mainAxisExtent: 292,
                mainAxisSpacing: 10,
                crossAxisSpacing: 10,
              ),
              itemBuilder: (context, index) => CounterCard(
                key: ValueKey(counters[index].id),
                counter: counters[index],
                onChange: onChange,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _MobileWorkspace extends StatelessWidget {
  const _MobileWorkspace({
    required this.counters,
    required this.history,
    required this.onChange,
  });

  final List<ShardCounter> counters;
  final List<HistoryEntry> history;
  final void Function(ShardCounter counter, int value, String action) onChange;

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(14),
      children: [
        const Text(
          'Shard Overview',
          style: TextStyle(fontSize: 24, fontWeight: FontWeight.w300),
        ),
        const SizedBox(height: 12),
        for (final counter in counters) ...[
          CounterCard(
            key: ValueKey(counter.id),
            counter: counter,
            onChange: onChange,
          ),
          const SizedBox(height: 10),
        ],
        const SizedBox(height: 10),
        HistoryList(
          history: history.take(8).toList(),
          counters: counters,
          compact: true,
        ),
      ],
    );
  }
}

class CounterCard extends StatefulWidget {
  const CounterCard({required this.counter, required this.onChange, super.key});

  final ShardCounter counter;
  final void Function(ShardCounter counter, int value, String action) onChange;

  @override
  State<CounterCard> createState() => _CounterCardState();
}

class _CounterCardState extends State<CounterCard> {
  late final TextEditingController _controller;

  @override
  void initState() {
    super.initState();
    _controller = TextEditingController(text: '${widget.counter.current}');
  }

  @override
  void didUpdateWidget(covariant CounterCard oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.counter.current != widget.counter.current) {
      _controller.text = '${widget.counter.current}';
      _controller.selection = TextSelection.collapsed(
        offset: _controller.text.length,
      );
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _submit(String raw) {
    final value = int.tryParse(raw.trim());
    if (value == null) {
      _controller.text = '${widget.counter.current}';
      return;
    }
    widget.onChange(widget.counter, value, 'manual');
  }

  @override
  Widget build(BuildContext context) {
    final isMythical = widget.counter.rewardType == 'mythical';
    final accent = widget.counter.accentColor;
    final chanceColor = isMythical ? _red : _gold;

    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: _card,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: accent, width: 1.2),
      ),
      child: LayoutBuilder(
        builder: (context, constraints) {
          final compact = constraints.maxWidth < 380;
          return Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              SizedBox(
                height: compact ? 96 : 116,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Image.asset(
                      widget.counter.assetPath,
                      width: compact ? 88 : 112,
                      height: compact ? 88 : 112,
                      fit: BoxFit.contain,
                    ),
                    SizedBox(
                      width: compact ? 96 : 116,
                      height: compact ? 96 : 116,
                      child: ProgressRing(counter: widget.counter),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 10),
              Wrap(
                alignment: WrapAlignment.center,
                spacing: 8,
                runSpacing: 8,
                children: [
                  _ActionButton(
                    label: '-',
                    color: accent,
                    onTap: () => widget.onChange(
                      widget.counter,
                      widget.counter.current - 1,
                      'minus',
                    ),
                  ),
                  _ActionButton(
                    label: '+',
                    color: accent,
                    onTap: () => widget.onChange(
                      widget.counter,
                      widget.counter.current + 1,
                      'plus',
                    ),
                  ),
                  if (widget.counter.threshold > 60)
                    _ActionButton(
                      label: '+10',
                      color: accent,
                      onTap: () => widget.onChange(
                        widget.counter,
                        widget.counter.current + 10,
                        'plus10',
                      ),
                    ),
                  _ActionButton(
                    label: 'Reset',
                    color: accent,
                    onTap: () => widget.onChange(widget.counter, 0, 'reset'),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  SizedBox(
                    width: 76,
                    height: 38,
                    child: TextField(
                      controller: _controller,
                      keyboardType: TextInputType.number,
                      textAlign: TextAlign.right,
                      style: const TextStyle(
                        fontSize: 17,
                        fontWeight: FontWeight.w800,
                      ),
                      decoration: InputDecoration(
                        filled: true,
                        fillColor: _field,
                        contentPadding: const EdgeInsets.symmetric(
                          horizontal: 8,
                        ),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(7),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(7),
                          borderSide: const BorderSide(
                            color: _blue,
                            width: 1.5,
                          ),
                        ),
                      ),
                      onSubmitted: _submit,
                      onEditingComplete: () => _submit(_controller.text),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Text(
                    '/ ${widget.counter.threshold}',
                    style: const TextStyle(
                      fontSize: 17,
                      fontWeight: FontWeight.w800,
                      color: Color(0xFFC9C9C9),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              Text(
                widget.counter.chanceLabel,
                style: TextStyle(
                  color: chanceColor,
                  fontWeight: FontWeight.w800,
                  fontSize: 13,
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}

class _ActionButton extends StatelessWidget {
  const _ActionButton({
    required this.label,
    required this.color,
    required this.onTap,
  });

  final String label;
  final Color color;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 34,
      child: OutlinedButton(
        onPressed: onTap,
        style: OutlinedButton.styleFrom(
          foregroundColor: Colors.white,
          side: BorderSide(color: color, width: 1.7),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
          padding: EdgeInsets.symmetric(horizontal: label == 'Reset' ? 16 : 14),
        ),
        child: Text(
          label,
          style: TextStyle(
            color: color == _red ? _red : Colors.white,
            fontSize: 17,
            fontWeight: FontWeight.w900,
          ),
        ),
      ),
    );
  }
}

class ProgressRing extends StatelessWidget {
  const ProgressRing({required this.counter, super.key});

  final ShardCounter counter;

  @override
  Widget build(BuildContext context) {
    return CustomPaint(
      painter: _RingPainter(
        progress: counter.progress,
        color: counter.accentColor,
      ),
      child: Center(
        child: Text(
          '${counter.current}',
          style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w800),
        ),
      ),
    );
  }
}

class _RingPainter extends CustomPainter {
  const _RingPainter({required this.progress, required this.color});

  final double progress;
  final Color color;

  @override
  void paint(Canvas canvas, Size size) {
    final stroke = math.max(7.0, size.shortestSide * 0.06);
    final rect =
        Offset(stroke / 2, stroke / 2) &
        Size(size.width - stroke, size.height - stroke);
    final base = Paint()
      ..color = const Color(0xFF686868)
      ..style = PaintingStyle.stroke
      ..strokeWidth = stroke
      ..strokeCap = StrokeCap.butt;
    final active = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = stroke
      ..strokeCap = StrokeCap.butt;

    canvas.drawArc(rect, 0, math.pi * 2, false, base);
    canvas.drawArc(rect, -math.pi / 2, math.pi * 2 * progress, false, active);
  }

  @override
  bool shouldRepaint(covariant _RingPainter oldDelegate) {
    return oldDelegate.progress != progress || oldDelegate.color != color;
  }
}

class HistoryList extends StatelessWidget {
  const HistoryList({
    required this.history,
    required this.counters,
    this.controller,
    this.compact = false,
    super.key,
  });

  final List<HistoryEntry> history;
  final List<ShardCounter> counters;
  final ScrollController? controller;
  final bool compact;

  @override
  Widget build(BuildContext context) {
    final byId = {for (final counter in counters) counter.id: counter};
    return Container(
      color: _panel,
      padding: EdgeInsets.all(compact ? 16 : 22),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            compact ? 'Последние действия' : 'История',
            style: TextStyle(
              fontSize: compact ? 20 : 26,
              fontWeight: FontWeight.w300,
            ),
          ),
          const SizedBox(height: 14),
          if (history.isEmpty)
            const ExpandedOrBox(
              compact: Text(
                'История пока пустая',
                style: TextStyle(color: _muted),
              ),
              expanded: Center(
                child: Text(
                  'История пока пустая',
                  style: TextStyle(color: _muted),
                ),
              ),
            )
          else
            ExpandedOrBox(
              compact: Column(
                children: [
                  for (final entry in history)
                    _HistoryTile(entry: entry, counter: byId[entry.counterId]),
                ],
              ),
              expanded: Expanded(
                child: ListView.separated(
                  controller: controller,
                  itemCount: history.length,
                  separatorBuilder: (_, __) =>
                      const Divider(color: Color(0xFF383838)),
                  itemBuilder: (context, index) => _HistoryTile(
                    entry: history[index],
                    counter: byId[history[index].counterId],
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

class ExpandedOrBox extends StatelessWidget {
  const ExpandedOrBox({
    required this.compact,
    required this.expanded,
    super.key,
  });

  final Widget compact;
  final Widget expanded;

  @override
  Widget build(BuildContext context) {
    final inScrollable =
        context.findAncestorWidgetOfExactType<ListView>() != null;
    return inScrollable ? compact : expanded;
  }
}

class _HistoryTile extends StatelessWidget {
  const _HistoryTile({required this.entry, required this.counter});

  final HistoryEntry entry;
  final ShardCounter? counter;

  @override
  Widget build(BuildContext context) {
    final title = counter?.title ?? entry.counterId;
    final delta = entry.delta > 0 ? '+${entry.delta}' : '${entry.delta}';
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        children: [
          if (counter != null)
            Image.asset(counter!.assetPath, width: 42, height: 42),
          if (counter != null) const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(fontWeight: FontWeight.w800),
                ),
                const SizedBox(height: 4),
                Text(
                  '${_actionLabel(entry.action)}: ${entry.before} → ${entry.after} ($delta)',
                  style: const TextStyle(
                    color: Color(0xFFD6D6D6),
                    fontSize: 13,
                  ),
                ),
              ],
            ),
          ),
          Text(
            _formatTime(entry.createdAt),
            style: const TextStyle(color: _muted, fontSize: 12),
          ),
        ],
      ),
    );
  }

  String _actionLabel(String action) {
    return switch (action) {
      'plus' => '+1',
      'plus10' => '+10',
      'minus' => '-1',
      'manual' => 'ручной ввод',
      'reset' => 'выпал герой / сброс',
      _ => action,
    };
  }

  String _formatTime(DateTime value) {
    final local = value.toLocal();
    String two(int number) => number.toString().padLeft(2, '0');
    return '${two(local.day)}.${two(local.month)} ${two(local.hour)}:${two(local.minute)}';
  }
}
