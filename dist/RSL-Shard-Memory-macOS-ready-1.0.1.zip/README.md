# Shard Mercy Counter

Personal Flutter app for tracking RAID-style shard mercy counters.

## Targets

- Windows
- Android
- macOS, built on a Mac with Xcode

## Commands

```powershell
flutter pub get
flutter run -d windows
flutter run -d android
flutter test
flutter analyze
```

If the local Flutter tool hangs on Windows, remove stale Dart/Flutter processes and the stale SDK cache lock, then retry:

```powershell
Get-Process dart -ErrorAction SilentlyContinue | Stop-Process -Force
Remove-Item C:\src\flutter\bin\cache\flutter.bat.lock -ErrorAction SilentlyContinue
flutter --no-version-check --version
```
